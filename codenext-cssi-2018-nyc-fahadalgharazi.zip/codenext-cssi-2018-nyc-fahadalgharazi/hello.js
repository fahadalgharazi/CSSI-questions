// Author: fahad algharazi
var readline = require("readline-sync");
var userName = readline.question("please enter your name or else!!")
console.log("hello " + userName);
console.log("2+2 is 4 minus 1 is 3 quick mafs11");